package com.infypoc.controller;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TreeTraversingParser;
import com.infypoc.model.Dependencies;
import com.infypoc.model.Dependency;
import com.infypoc.model.Parent;
import com.infypoc.model.Project;

@RestController
@RequestMapping
public class FileReadController {
	
	@GetMapping(value="/readpom")
	public ResponseEntity<String> getReadMe(){
		String readMeData = "Can't Fetch";
		JSONObject json = new JSONObject();
		
		
		try {
			
			GitHub github = GitHub.connect("soumyamallick97", "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");
			
			String url = github.getApiUrl();	
			
			System.out.println(url);
			
			
//			readMeData = new RestTemplate().getForObject("https://raw.githubusercontent.com/google/guava/master/README.md", String.class);
			readMeData = new RestTemplate().getForObject("https://raw.githubusercontent.com/google/guava/master/guava/pom.xml", String.class);
		
			

			json = XML.toJSONObject(readMeData);
			ObjectMapper mapper = new ObjectMapper();
			
			Parent parent = mapper.readValue((json.getJSONObject("project").getJSONObject("parent")).toString(), Parent.class);
			System.out.println(parent);
			
//			JSONObject dependencies = json.getJSONObject("project").getJSONObject("dependencies");
//			System.out.println(dependencies.getJSONArray("dependency"));
			
			List<Dependency> list = new ArrayList<>();			
			list = mapper.readValue((json.getJSONObject("project").getJSONObject("dependencies").getJSONArray("dependency")).toString(), 
					mapper.getTypeFactory()
					.constructCollectionType(List.class, Dependency.class));
			
			list.forEach(s -> System.out.println(s));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ResponseEntity.ok(json.toString());
	}
	
	
	
	@SuppressWarnings("deprecation")
	static JsonNode convertJsonFormat(JSONObject json) {
	    ObjectNode ret = JsonNodeFactory.instance.objectNode();

	    @SuppressWarnings("unchecked")
	    Iterator<String> iterator = json.keys();
	    for (; iterator.hasNext();) {
	        String key = iterator.next();
	        Object value;
	        try {
	            value = json.get(key);
	        } catch (JSONException e) {
	            throw new RuntimeException(e);
	        }
	        if (json.isNull(key))
	            ret.putNull(key);
	        else if (value instanceof String)
	            ret.put(key, (String) value);
	        else if (value instanceof Integer)
	            ret.put(key, (Integer) value);
	        else if (value instanceof Long)
	            ret.put(key, (Long) value);
	        else if (value instanceof Double)
	            ret.put(key, (Double) value);
	        else if (value instanceof Boolean)
	            ret.put(key, (Boolean) value);
	        else if (value instanceof JSONObject)
	            ret.put(key, convertJsonFormat((JSONObject) value));
	        else if (value instanceof JSONArray)
	            ret.put(key, convertJsonFormat((JSONArray) value));
	        else
	            throw new RuntimeException("not prepared for converting instance of class " + value.getClass());
	    }
	    return ret;
	}
	
	static JsonNode convertJsonFormat(JSONArray json) {
	    ArrayNode ret = JsonNodeFactory.instance.arrayNode();
	    for (int i = 0; i < json.length(); i++) {
	        Object value;
	        try {
	            value = json.get(i);
	        } catch (JSONException e) {
	            throw new RuntimeException(e);
	        }
	        if (json.isNull(i))
	            ret.addNull();
	        else if (value instanceof String)
	            ret.add((String) value);
	        else if (value instanceof Integer)
	            ret.add((Integer) value);
	        else if (value instanceof Long)
	            ret.add((Long) value);
	        else if (value instanceof Double)
	            ret.add((Double) value);
	        else if (value instanceof Boolean)
	            ret.add((Boolean) value);
	        else if (value instanceof JSONObject)
	            ret.add(convertJsonFormat((JSONObject) value));
	        else if (value instanceof JSONArray)
	            ret.add(convertJsonFormat((JSONArray) value));
	        else
	            throw new RuntimeException("not prepared for converting instance of class " + value.getClass());
	    }
	    return ret;
	}
}
