package com.infypoc.model;

public class Project {

	private Parent parent;
	private Dependencies dependencies;
	
	public Parent getParent() {
		return parent;
	}
	public void setParent(Parent parent) {
		this.parent = parent;
	}
	public Dependencies getDependencies() {
		return dependencies;
	}
	public void setDependencies(Dependencies dependencies) {
		this.dependencies = dependencies;
	}
	@Override
	public String toString() {
		return "Project [parent=" + parent + ", dependencies=" + dependencies + "]";
	}
	
	
	
}
