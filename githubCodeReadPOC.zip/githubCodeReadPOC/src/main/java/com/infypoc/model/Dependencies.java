package com.infypoc.model;

import java.util.List;

public class Dependencies {
	private List<Dependency> dependencyList;

	public List<Dependency> getDependencyList() {
		return dependencyList;
	}

	public void setDependencyList(List<Dependency> dependencyList) {
		this.dependencyList = dependencyList;
	}

	@Override
	public String toString() {
		return "Dependencies [dependencyList=" + dependencyList + "]";
	}
	
	
}
